from flask import Flask, render_template, request, redirect, url_for, jsonify
import sqlite3
from datetime import datetime

app = Flask(__name__)

# Инициализация базы данных
def init_db():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_completed BOOLEAN DEFAULT FALSE
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/')
def index():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row  # Для доступа к колонкам по имени
    c = conn.cursor()
    
    # Получаем задачи, отсортированные по статусу и дате
    c.execute('SELECT * FROM tasks ORDER BY is_completed, created_at DESC')
    tasks = c.fetchall()
    conn.close()
    
    return render_template('index.html', tasks=tasks)

# Добавление новой задачи
@app.route('/add', methods=['POST'])
def add_task():
    title = request.form['title']
    description = request.form['description']
    
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('INSERT INTO tasks (title, description) VALUES (?, ?)', 
              (title, description))
    conn.commit()
    conn.close()
    
    return redirect(url_for('index'))

# Отметить задачу как выполненную
@app.route('/task/<int:task_id>/complete', methods=['POST'])
def complete_task(task_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('UPDATE tasks SET is_completed = TRUE WHERE id = ?', (task_id,))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

# Вернуть задачу в активные
@app.route('/task/<int:task_id>/incomplete', methods=['POST'])
def incomplete_task(task_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('UPDATE tasks SET is_completed = FALSE WHERE id = ?', (task_id,))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

# Удалить задачу
@app.route('/task/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('DELETE FROM tasks WHERE id = ?', (task_id,))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

# Страница редактирования задачи
@app.route('/edit/<int:task_id>')
def edit_task(task_id):
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('SELECT * FROM tasks WHERE id = ?', (task_id,))
    task = c.fetchone()
    conn.close()
    
    if not task:
        return redirect(url_for('index'))
    
    return render_template('edit.html', task=task)

# Обновление задачи
@app.route('/update/<int:task_id>', methods=['POST'])
def update_task(task_id):
    title = request.form['title']
    description = request.form['description']
    
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('UPDATE tasks SET title = ?, description = ? WHERE id = ?', 
              (title, description, task_id))
    conn.commit()
    conn.close()
    
    return redirect(url_for('index'))

if __name__ == '__main__':
    init_db()  # Инициализируем базу данных при запуске
    app.run(debug=True)