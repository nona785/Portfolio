//  Ждем загрузки DOM
document.addEventListener('DOMContentLoaded', function() {
    console.log('To-Do List loaded successfully!');
});

// Функция для выполнения AJAX-запросов
async function makeRequest(url, method = 'GET', data = null) {
    const options = {
        method: method,
        headers: {
            'Content-Type': 'application/json',
        }
    };
    
    if (data && (method === 'POST' || method === 'PUT')) {
        options.body = JSON.stringify(data);
    }
    
    try {
        const response = await fetch(url, options);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error('Ошибка:', error);
        showNotification('Произошла ошибка при выполнении запроса', 'error');
        return null;
    }
}

// Показ уведомлений
function showNotification(message, type = 'info') {
    // Создаем элемент уведомления
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        background: ${type === 'error' ? '#f56565' : '#48bb78'};
        color: white;
        border-radius: 5px;
        z-index: 1000;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        animation: slideIn 0.3s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    // Удаляем через 3 секунды
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Добавляем CSS анимации для уведомлений
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);

// Отметить задачу как выполненную
async function completeTask(taskId) {
    const result = await makeRequest(`/task/${taskId}/complete`, 'POST');
    if (result && result.success) {
        showNotification('Задача отмечена как выполненная!', 'success');
        // Плавное обновление интерфейса
        setTimeout(() => {
            location.reload();
        }, 1000);
    }
}

// Вернуть задачу в активные
async function incompleteTask(taskId) {
    const result = await makeRequest(`/task/${taskId}/incomplete`, 'POST');
    if (result && result.success) {
        showNotification('Задача возвращена в активные!', 'success');
        setTimeout(() => {
            location.reload();
        }, 1000);
    }
}

// Удалить задачу
async function deleteTask(taskId) {
    if (confirm('Вы уверены, что хотите удалить эту задачу?')) {
        const result = await makeRequest(`/task/${taskId}`, 'DELETE');
        if (result && result.success) {
            // Плавное удаление элемента из DOM
            const taskElement = document.querySelector(`[data-task-id="${taskId}"]`);
            if (taskElement) {
                taskElement.style.transition = 'all 0.3s ease';
                taskElement.style.opacity = '0';
                taskElement.style.transform = 'translateX(-100%)';
                setTimeout(() => {
                    if (taskElement.parentNode) {
                        taskElement.parentNode.removeChild(taskElement);
                    }
                }, 300);
            }
            showNotification('Задача удалена!', 'success');
        }
    }
}

// Добавляем обработчики событий после загрузки DOM
document.addEventListener('DOMContentLoaded', function() {
    // Добавляем подтверждение для всех форм удаления
    const deleteForms = document.querySelectorAll('form[action*="delete"]');
    deleteForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!confirm('Вы уверены, что хотите удалить эту задачу?')) {
                e.preventDefault();
            }
        });
    });
    
    // Добавляем анимацию при наведении на задачи
    const taskItems = document.querySelectorAll('.task-item');
    taskItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
});