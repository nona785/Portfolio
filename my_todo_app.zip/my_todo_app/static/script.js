// Функция для выполнения AJAX-запросов
async function makeRequest(url, method = 'GET', data = null) {
    const options = {
        method: method,
        headers: {
            'Content-Type': 'application/json',
        }
    };
    
    if (data && (method === 'POST' || method === 'PUT')) {
        options.body = JSON.stringify(data);
    }
    
    try {
        const response = await fetch(url, options);
        return await response.json();
    } catch (error) {
        console.error('Ошибка:', error);
        alert('Произошла ошибка при выполнении запроса');
    }
}

// Отметить задачу как выполненную
async function completeTask(taskId) {
    const result = await makeRequest(`/task/${taskId}/complete`, 'POST');
    if (result && result.success) {
        location.reload(); // Перезагружаем страницу для обновления списка
    }
}

// Вернуть задачу в активные
async function incompleteTask(taskId) {
    const result = await makeRequest(`/task/${taskId}/incomplete`, 'POST');
    if (result && result.success) {
        location.reload();
    }
}

// Удалить задачу
async function deleteTask(taskId) {
    if (confirm('Вы уверены, что хотите удалить эту задачу?')) {
        const result = await makeRequest(`/task/${taskId}`, 'DELETE');
        if (result && result.success) {
            // Удаляем элемент из DOM без перезагрузки страницы
            const taskElement = document.querySelector(`[data-task-id="${taskId}"]`);
            if (taskElement) {
                taskElement.style.opacity = '0';
                setTimeout(() => taskElement.remove(), 300);
            }
        }
    }
}

// Поиск задач (дополнительная функция)
function searchTasks() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const tasks = document.querySelectorAll('.task-item');
    
    tasks.forEach(task => {
        const title = task.querySelector('h3').textContent.toLowerCase();
        const description = task.querySelector('p')?.textContent.toLowerCase() || '';
        
        if (title.includes(searchTerm) || description.includes(searchTerm)) {
            task.style.display = 'flex';
        } else {
            task.style.display = 'none';
        }
    });
}