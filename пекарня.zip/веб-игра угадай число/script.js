document.addEventListener('DOMContentLoaded', function() {
    // Элементы DOM
    const guessInput = document.getElementById('guess-input');
    const checkBtn = document.getElementById('check-btn');
    const newGameBtn = document.getElementById('new-game-btn');
    const hintElement = document.getElementById('hint');
    const character = document.querySelector('.character');
    const target = document.querySelector('.target');
    const gameField = document.querySelector('.game-field');
    
    // Константы игры
    const MIN_NUMBER = 1;
    const MAX_NUMBER = 100;
    const MAX_DIFFERENCE = MAX_NUMBER - MIN_NUMBER;
    const FIELD_HEIGHT = gameField.offsetHeight - character.offsetHeight;
    
    // Переменные игры
    let secretNumber;
    let attempts = 0;
    let gameOver = false;
    let previousDifference = MAX_DIFFERENCE;
    let hintTimeout = null;
    
    // Инициализация игры
    initGame();
    
    // Обработчики событий
    checkBtn.addEventListener('click', checkGuess);
    newGameBtn.addEventListener('click', initGame);
    guessInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            checkGuess();
        }
    });
    
    // Функция показа подсказки
    function showHint(message, bgColor) {
        // Очищаем предыдущий таймер
        if (hintTimeout) {
            clearTimeout(hintTimeout);
            hintElement.classList.remove('show');
        }
        
        // Устанавливаем новое сообщение и цвет фона
        hintElement.textContent = message;
        hintElement.style.backgroundColor = bgColor;
        
        // Даем время для обновления DOM перед анимацией
        setTimeout(() => {
            hintElement.classList.add('show');
        }, 10);
        
        // Скрываем через 5 секунд с плавной анимацией
        hintTimeout = setTimeout(() => {
            hintElement.classList.remove('show');
            
            // После завершения анимации скрытия полностью убираем подсказку
            setTimeout(() => {
                hintElement.textContent = '';
            }, 500); // Ждем завершения анимации (0.5s)
        }, 5000);
    }
    
    // Функция инициализации новой игры
    function initGame() {
        secretNumber = generateRandomNumber(MIN_NUMBER, MAX_NUMBER);
        attempts = 0;
        gameOver = false;
        previousDifference = MAX_DIFFERENCE;
        
        // Сброс интерфейса
        guessInput.value = '';
        hintElement.classList.remove('show'); // Скрываем подсказку
        
        // Сброс позиции персонажа (внизу экрана)
        character.style.bottom = '200px';
        
        // Активация элементов ввода
        guessInput.disabled = false;
        checkBtn.disabled = false;
        
        // Убрать анимацию победы
        target.classList.remove('win-glow');
        
        console.log(`Загаданное число: ${secretNumber}`); // Для отладки
    }
    
    // Генерация случайного числа
    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    
    // Проверка введенного числа
    function checkGuess() {
        if (gameOver) return;
        
        const userGuess = parseInt(guessInput.value);
        
        // Проверка валидности ввода
        if (isNaN(userGuess) || userGuess < MIN_NUMBER || userGuess > MAX_NUMBER) {
            showHint(`Пожалуйста, введите число от ${MIN_NUMBER} до ${MAX_NUMBER}!`, 'rgba(255, 193, 7, 0.9)');
            return;
        }
        
        attempts++;
        
        // Проверка на победу
        if (userGuess === secretNumber) {
            handleWin();
            return;
        }
        
        // Расчет разницы и обновление позиции персонажа
        const currentDifference = Math.abs(secretNumber - userGuess);
        updateCharacterPosition(currentDifference);
        
        // Подсказка
        if (userGuess < secretNumber) {
            showHint(`Слишком мало! Попытка ${attempts}.`, 'rgba(33, 150, 243, 0.9)');
        } else {
            showHint(`Слишком много! Попытка ${attempts}.`, 'rgba(244, 67, 54, 0.9)');
        }
        
        // Визуальная обратная связь
        if (currentDifference < previousDifference) {
            character.classList.add('positive-feedback');
            setTimeout(() => character.classList.remove('positive-feedback'), 500);
        } else {
            character.classList.add('negative-feedback');
            setTimeout(() => character.classList.remove('negative-feedback'), 500);
        }
        
        previousDifference = currentDifference;
        guessInput.value = '';
        guessInput.focus();
    }
    
    // Обновление позиции персонажа
    function updateCharacterPosition(currentDifference) {
        const progress = 1 - (currentDifference / MAX_DIFFERENCE);
        const newBottom = 30 + (FIELD_HEIGHT * (1 - progress));
        character.style.bottom = `${newBottom}px`;
    }
    
    // Обработка победы
    function handleWin() {
        gameOver = true;
        
        // Установка персонажа точно у цели
        character.style.bottom = '20px';
        
        // Сообщение о победе
        showHint(`Поздравляем! Вы угадали число ${secretNumber} за ${attempts} попыток!`, 'rgba(76, 175, 80, 0.9)');
        
        // Анимация победы
        target.classList.add('win-glow');
        createConfetti();
        
        // Блокировка элементов ввода
        guessInput.disabled = true;
        checkBtn.disabled = true;
    }
    
    // Создание конфетти для анимации победы
    function createConfetti() {
        const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];
        
        for (let i = 0; i < 50; i++) {
            const confetti = document.createElement('div');
            confetti.classList.add('confetti');
            confetti.style.left = `${Math.random() * 100}%`;
            confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
            confetti.style.width = `${5 + Math.random() * 10}px`;
            confetti.style.height = `${5 + Math.random() * 10}px`;
            confetti.style.borderRadius = Math.random() > 0.5 ? '50%' : '0';
            
            gameField.appendChild(confetti);
            
            const animationDuration = 1 + Math.random() * 2;
            const animationDelay = Math.random() * 1;
            
            confetti.style.animation = `
                fade-in 0.5s ease-out forwards,
                ${i % 2 ? 'fall-left' : 'fall-right'} ${animationDuration}s ease-in ${animationDelay}s forwards
            `;
            
            setTimeout(() => {
                if (confetti.parentNode) {
                    confetti.parentNode.removeChild(confetti);
                }
            }, (animationDelay + animationDuration) * 1000);
        }
    }
});