// Mobile menu toggle
const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
const mainNav = document.getElementById('main-nav');
const overlay = document.getElementById('overlay');

mobileMenuBtn.addEventListener('click', () => {
    mainNav.classList.toggle('active');
    overlay.classList.toggle('active');
});

// Close mobile menu when clicking on links
const navLinks = document.querySelectorAll('nav a');
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        mainNav.classList.remove('active');
        overlay.classList.remove('active');
    });
});

// Cart functionality
const cart = [];
const addToCartButtons = document.querySelectorAll('.add-to-cart');
const cartModal = document.getElementById('cart-modal');
const closeCartBtn = document.getElementById('close-cart');
const cartItemsContainer = document.getElementById('cart-items');
const cartTotalElement = document.getElementById('cart-total');
const checkoutBtn = document.getElementById('checkout-btn');

addToCartButtons.forEach(button => {
    button.addEventListener('click', () => {
        const product = button.getAttribute('data-product');
        const price = parseInt(button.getAttribute('data-price'));
        
        // Check if product already in cart
        const existingItem = cart.find(item => item.product === product);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({
                product,
                price,
                quantity: 1
            });
        }
        
        updateCart();
        
        // Show cart modal
        cartModal.classList.add('active');
        overlay.classList.add('active');
    });
});

closeCartBtn.addEventListener('click', () => {
    cartModal.classList.remove('active');
    overlay.classList.remove('active');
});

overlay.addEventListener('click', () => {
    cartModal.classList.remove('active');
    overlay.classList.remove('active');
    mainNav.classList.remove('active');
});

checkoutBtn.addEventListener('click', () => {
    alert('Заказ оформлен! Спасибо за покупку!');
    cart.length = 0;
    updateCart();
    cartModal.classList.remove('active');
    overlay.classList.remove('active');
});

function updateCart() {
    // Clear cart items container
    cartItemsContainer.innerHTML = '';
    
    let total = 0;
    
    // Add items to cart
    cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        
        const cartItemElement = document.createElement('div');
        cartItemElement.classList.add('cart-item');
        cartItemElement.innerHTML = `
            <div>
                <div>${item.product}</div>
                <div>${item.price} ₽ × ${item.quantity}</div>
            </div>
            <div>${itemTotal} ₽</div>
        `;
        
        cartItemsContainer.appendChild(cartItemElement);
    });
    
    // Update total
    cartTotalElement.textContent = `Итого: ${total} ₽`;
}

// Form submission
const feedbackForm = document.getElementById('feedback-form');

feedbackForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;
    
    // Here you would typically send the form data to a server
    console.log('Form submitted:', { name, email, message });
    
    alert('Спасибо за ваше сообщение! Мы свяжемся с вами в ближайшее время.');
    feedbackForm.reset();
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
            window.scrollTo({
                top: targetElement.offsetTop - 80,
                behavior: 'smooth'
            });
        }
    });
});

// Инициализация карты
document.addEventListener('DOMContentLoaded', function() {
// Ждем загрузки API Яндекс.Карт
if (typeof ymaps !== 'undefined') {
    ymaps.ready(init);
} else {
    console.error('Yandex Maps API не загрузился');
}
});

function init() {
// Создаем карту
var myMap = new ymaps.Map("map", {
    center: [55.76, 37.64], // Координаты центра карты (Москва)
    zoom: 14 // Уровень масштабирования
});

// Задаем адрес для геокодирования
var address = "г. Москва, ул. Пекарская, д. 15";

// Геокодируем адрес
ymaps.geocode(address).then(function (res) {
    var firstGeoObject = res.geoObjects.get(0);
    
    // Получаем координаты
    var coordinates = firstGeoObject.geometry.getCoordinates();
    
    // Перемещаем центр карты на найденные координаты
    myMap.setCenter(coordinates);
    
    // Добавляем метку на карту
    var myPlacemark = new ymaps.Placemark(coordinates, {
    hintContent: 'Пекарня "Вкусный уголок"',
    balloonContent: address
    }, {
    preset: 'islands#redDotIcon'
    });
    
    myMap.geoObjects.add(myPlacemark);
});
}
